const state = {
    isLogin: false,
    username: "",
    storedWord: "",
    loginErrMessage: ""
};

export default state;